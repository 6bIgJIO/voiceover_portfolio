BestVoice React demo. Deploy to Vercel or GitHub. Replace assets and implement build step.
